from quiz_brain import Quizbrain

z=Quizbrain()

z.startquiz()

