
class Quiz: #Pascal case to name the class as the first word
    """Invoke this class to add questions to the quiz"""

    def __init__(self,question="Default Question",value=False): #contstructor (self refers to the object that is being intialized as defined below)
        self.question=question
        self.value=value
        




